package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText number;
    EditText number1;
    Button button1;
    Button button2;
    Button button3;
    Button button4;
    float result=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        number=findViewById(R.id.num1);
        number1=findViewById(R.id.num2);
        button1=findViewById(R.id.add);
        button2=findViewById(R.id.sub);
        button3=findViewById(R.id.mul);
        button4=findViewById(R.id.div);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Float n1=Float.parseFloat(number.getText().toString());
                Float n2=Float.parseFloat(number1.getText().toString());
                result=n1+n2;
                Toast.makeText(MainActivity.this, "Sum is" + result, Toast.LENGTH_SHORT).show();

            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Float n1=Float.parseFloat(number.getText().toString());
                Float n2=Float.parseFloat(number1.getText().toString());
                result=n1-n2;
                Toast.makeText(MainActivity.this, "difference is" + result, Toast.LENGTH_SHORT).show();
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Float n1=Float.parseFloat(number.getText().toString());
                Float n2=Float.parseFloat(number1.getText().toString());
                result=n1*n2;
                Toast.makeText(MainActivity.this, "product is" + result, Toast.LENGTH_SHORT).show();
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Float n1=Float.parseFloat(number.getText().toString());
                Float n2=Float.parseFloat(number1.getText().toString());
                result=n1/n2;
                Toast.makeText(MainActivity.this, "division is" + result, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
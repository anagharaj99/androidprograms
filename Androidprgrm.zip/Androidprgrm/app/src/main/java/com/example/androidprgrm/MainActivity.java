package com.example.androidprgrm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText username;
    EditText password;
    Button login;
    String name="Admin";
    String name1="1234";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        username = findViewById(R.id.usr);
        password = findViewById(R.id.Pass);
        login = findViewById(R.id.lgnbt);

        login.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                String inpName = username.getText().toString();
                String inppass = password.getText().toString();

                if (inpName.isEmpty() || inppass.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Fields are empty", Toast.LENGTH_SHORT).show();
                }
                else {

                    if (inpName.equals(name) && inppass.equals(name1)) {
                        Toast.makeText(MainActivity.this, "Success", Toast.LENGTH_SHORT).show();
                    }
                 else{
                    Toast.makeText(MainActivity.this, "unsuccess", Toast.LENGTH_SHORT).show();
                }
            }
        }


    });
 }
}
